<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

class CreatePaymentsTable extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::create('payments', function (Blueprint $table) {
            $table->id();
            $table->string('pay_amount');
            $table->string('pay_date');
            $table->integer('payment_type')->comment('0 => Cash, 1 => Bank');
            $table->unsignedInteger('bank_id')->nullable();
            $table->string('bank_check_date')->nullable();
            $table->string('bank_check_number')->nullable();
            $table->unsignedInteger('branch_id')->nullable();
            $table->unsignedBigInteger('passenger_id');
            $table->foreign('passenger_id')->references('id')->on('passengers')->onDelete('CasCade');
            $table->timestamps();
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::dropIfExists('payments');
    }
}
