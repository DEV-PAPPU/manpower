"use strict";
(self["webpackChunk"] = self["webpackChunk"] || []).push([["resources_js_components_Admin_index_vue"],{

/***/ "./node_modules/babel-loader/lib/index.js??clonedRuleSet-5[0].rules[0].use[0]!./node_modules/vue-loader/lib/index.js??vue-loader-options!./resources/js/components/Admin/index.vue?vue&type=script&lang=js&":
/*!******************************************************************************************************************************************************************************************************************!*\
  !*** ./node_modules/babel-loader/lib/index.js??clonedRuleSet-5[0].rules[0].use[0]!./node_modules/vue-loader/lib/index.js??vue-loader-options!./resources/js/components/Admin/index.vue?vue&type=script&lang=js& ***!
  \******************************************************************************************************************************************************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = ({
  data: function data() {
    return {
      text: 'hello'
    };
  },
  methods: {
    menu: function menu() {
      var note = document.querySelector(".sidebar-brand-text"); // note.style.backgroundColor = 'yellow';

      note.style.display = 'none';
    }
  }
});

/***/ }),

/***/ "./resources/js/components/Admin/index.vue":
/*!*************************************************!*\
  !*** ./resources/js/components/Admin/index.vue ***!
  \*************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var _index_vue_vue_type_template_id_eab2c812___WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./index.vue?vue&type=template&id=eab2c812& */ "./resources/js/components/Admin/index.vue?vue&type=template&id=eab2c812&");
/* harmony import */ var _index_vue_vue_type_script_lang_js___WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./index.vue?vue&type=script&lang=js& */ "./resources/js/components/Admin/index.vue?vue&type=script&lang=js&");
/* harmony import */ var _node_modules_vue_loader_lib_runtime_componentNormalizer_js__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! !../../../../node_modules/vue-loader/lib/runtime/componentNormalizer.js */ "./node_modules/vue-loader/lib/runtime/componentNormalizer.js");





/* normalize component */
;
var component = (0,_node_modules_vue_loader_lib_runtime_componentNormalizer_js__WEBPACK_IMPORTED_MODULE_2__["default"])(
  _index_vue_vue_type_script_lang_js___WEBPACK_IMPORTED_MODULE_1__["default"],
  _index_vue_vue_type_template_id_eab2c812___WEBPACK_IMPORTED_MODULE_0__.render,
  _index_vue_vue_type_template_id_eab2c812___WEBPACK_IMPORTED_MODULE_0__.staticRenderFns,
  false,
  null,
  null,
  null
  
)

/* hot reload */
if (false) { var api; }
component.options.__file = "resources/js/components/Admin/index.vue"
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (component.exports);

/***/ }),

/***/ "./resources/js/components/Admin/index.vue?vue&type=script&lang=js&":
/*!**************************************************************************!*\
  !*** ./resources/js/components/Admin/index.vue?vue&type=script&lang=js& ***!
  \**************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var _node_modules_babel_loader_lib_index_js_clonedRuleSet_5_0_rules_0_use_0_node_modules_vue_loader_lib_index_js_vue_loader_options_index_vue_vue_type_script_lang_js___WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! -!../../../../node_modules/babel-loader/lib/index.js??clonedRuleSet-5[0].rules[0].use[0]!../../../../node_modules/vue-loader/lib/index.js??vue-loader-options!./index.vue?vue&type=script&lang=js& */ "./node_modules/babel-loader/lib/index.js??clonedRuleSet-5[0].rules[0].use[0]!./node_modules/vue-loader/lib/index.js??vue-loader-options!./resources/js/components/Admin/index.vue?vue&type=script&lang=js&");
 /* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (_node_modules_babel_loader_lib_index_js_clonedRuleSet_5_0_rules_0_use_0_node_modules_vue_loader_lib_index_js_vue_loader_options_index_vue_vue_type_script_lang_js___WEBPACK_IMPORTED_MODULE_0__["default"]); 

/***/ }),

/***/ "./resources/js/components/Admin/index.vue?vue&type=template&id=eab2c812&":
/*!********************************************************************************!*\
  !*** ./resources/js/components/Admin/index.vue?vue&type=template&id=eab2c812& ***!
  \********************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "render": () => (/* reexport safe */ _node_modules_vue_loader_lib_loaders_templateLoader_js_vue_loader_options_node_modules_vue_loader_lib_index_js_vue_loader_options_index_vue_vue_type_template_id_eab2c812___WEBPACK_IMPORTED_MODULE_0__.render),
/* harmony export */   "staticRenderFns": () => (/* reexport safe */ _node_modules_vue_loader_lib_loaders_templateLoader_js_vue_loader_options_node_modules_vue_loader_lib_index_js_vue_loader_options_index_vue_vue_type_template_id_eab2c812___WEBPACK_IMPORTED_MODULE_0__.staticRenderFns)
/* harmony export */ });
/* harmony import */ var _node_modules_vue_loader_lib_loaders_templateLoader_js_vue_loader_options_node_modules_vue_loader_lib_index_js_vue_loader_options_index_vue_vue_type_template_id_eab2c812___WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! -!../../../../node_modules/vue-loader/lib/loaders/templateLoader.js??vue-loader-options!../../../../node_modules/vue-loader/lib/index.js??vue-loader-options!./index.vue?vue&type=template&id=eab2c812& */ "./node_modules/vue-loader/lib/loaders/templateLoader.js??vue-loader-options!./node_modules/vue-loader/lib/index.js??vue-loader-options!./resources/js/components/Admin/index.vue?vue&type=template&id=eab2c812&");


/***/ }),

/***/ "./node_modules/vue-loader/lib/loaders/templateLoader.js??vue-loader-options!./node_modules/vue-loader/lib/index.js??vue-loader-options!./resources/js/components/Admin/index.vue?vue&type=template&id=eab2c812&":
/*!***********************************************************************************************************************************************************************************************************************!*\
  !*** ./node_modules/vue-loader/lib/loaders/templateLoader.js??vue-loader-options!./node_modules/vue-loader/lib/index.js??vue-loader-options!./resources/js/components/Admin/index.vue?vue&type=template&id=eab2c812& ***!
  \***********************************************************************************************************************************************************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "render": () => (/* binding */ render),
/* harmony export */   "staticRenderFns": () => (/* binding */ staticRenderFns)
/* harmony export */ });
var render = function () {
  var _vm = this
  var _h = _vm.$createElement
  var _c = _vm._self._c || _h
  return _c("div", { staticClass: "d-flex", attrs: { id: "div__wrapper" } }, [
    _c(
      "ul",
      {
        staticClass:
          "navbar-nav bg-gradient-primary sidebar sidebar-dark accordion",
        attrs: { id: "accordionSidebar" },
      },
      [
        _vm._m(0),
        _vm._v(" "),
        _c("hr", { staticClass: "sidebar-divider my-0" }),
        _vm._v(" "),
        _vm._m(1),
        _vm._v(" "),
        _c("hr", { staticClass: "sidebar-divider" }),
        _vm._v(" "),
        _c("div", { staticClass: "sidebar-heading" }, [
          _vm._v("\n            Interface\n        "),
        ]),
        _vm._v(" "),
        _vm._m(2),
        _vm._v(" "),
        _vm._m(3),
        _vm._v(" "),
        _c("hr", { staticClass: "sidebar-divider" }),
        _vm._v(" "),
        _c("div", { staticClass: "sidebar-heading" }, [
          _vm._v("\n            Addons\n        "),
        ]),
        _vm._v(" "),
        _c("li", { staticClass: "nav-item" }, [
          _vm._m(4),
          _vm._v(" "),
          _c(
            "div",
            {
              staticClass: "collapse",
              attrs: {
                id: "collapsePages",
                "aria-labelledby": "headingPages",
                "data-parent": "#accordionSidebar",
              },
            },
            [
              _c(
                "div",
                { staticClass: "bg-white py-2 collapse-inner rounded" },
                [
                  _c("h6", { staticClass: "collapse-header" }, [
                    _vm._v("Login Screens:"),
                  ]),
                  _vm._v(" "),
                  _c(
                    "router-link",
                    {
                      staticClass: "collapse-item",
                      attrs: { to: { name: "AddPassenger" } },
                    },
                    [_vm._v("Add Passenger")]
                  ),
                  _vm._v(" "),
                  _c(
                    "a",
                    {
                      staticClass: "collapse-item",
                      attrs: { href: "login.html" },
                    },
                    [_vm._v("Login")]
                  ),
                  _vm._v(" "),
                  _c(
                    "a",
                    {
                      staticClass: "collapse-item",
                      attrs: { href: "register.html" },
                    },
                    [_vm._v("Register")]
                  ),
                ],
                1
              ),
            ]
          ),
        ]),
        _vm._v(" "),
        _vm._m(5),
        _vm._v(" "),
        _vm._m(6),
      ]
    ),
    _vm._v(" "),
    _c(
      "div",
      { staticClass: "d-flex flex-column", attrs: { id: "content-wrapper" } },
      [
        _c("div", { attrs: { id: "content" } }, [
          _c(
            "nav",
            {
              staticClass:
                "navbar navbar-expand navbar-light bg-white topbar mb-4 static-top shadow",
            },
            [
              _c(
                "button",
                {
                  staticClass: "btn btn-link rounded-circle mr-3",
                  attrs: { id: "sidebarToggleTop" },
                  on: { click: _vm.menu },
                },
                [_c("i", { staticClass: "fa fa-bars" })]
              ),
              _vm._v(" "),
              _vm._m(7),
              _vm._v(" "),
              _vm._m(8),
            ]
          ),
          _vm._v(" "),
          _vm._m(9),
        ]),
        _vm._v(" "),
        _c("footer", { staticClass: "sticky-footer bg-white" }, [
          _c("div", { staticClass: "container my-auto" }, [
            _c("div", { staticClass: "copyright text-center my-auto" }, [
              _c("span", [
                _vm._v("Copyright © Your Website 2021 " + _vm._s(_vm.text)),
              ]),
            ]),
          ]),
        ]),
      ]
    ),
  ])
}
var staticRenderFns = [
  function () {
    var _vm = this
    var _h = _vm.$createElement
    var _c = _vm._self._c || _h
    return _c(
      "a",
      {
        staticClass:
          "sidebar-brand d-flex align-items-center justify-content-center",
        attrs: { href: "index.html" },
      },
      [
        _c("div", { staticClass: "sidebar-brand-icon rotate-n-15" }, [
          _c("i", { staticClass: "fas fa-laugh-wink" }),
        ]),
        _vm._v(" "),
        _c("div", { staticClass: "sidebar-brand-text mx-3" }, [
          _vm._v("SB Admin "),
          _c("sup", [_vm._v("2")]),
        ]),
      ]
    )
  },
  function () {
    var _vm = this
    var _h = _vm.$createElement
    var _c = _vm._self._c || _h
    return _c("li", { staticClass: "nav-item active" }, [
      _c("a", { staticClass: "nav-link", attrs: { href: "index.html" } }, [
        _c("i", { staticClass: "fas fa-fw fa-tachometer-alt" }),
        _vm._v(" "),
        _c("span", [_vm._v("Dashboard")]),
      ]),
    ])
  },
  function () {
    var _vm = this
    var _h = _vm.$createElement
    var _c = _vm._self._c || _h
    return _c("li", { staticClass: "nav-item" }, [
      _c(
        "a",
        {
          staticClass: "nav-link collapsed",
          attrs: {
            href: "#",
            "data-toggle": "collapse",
            "data-target": "#collapseTwo",
            "aria-expanded": "true",
            "aria-controls": "collapseTwo",
          },
        },
        [
          _c("i", { staticClass: "fas fa-fw fa-cog" }),
          _vm._v(" "),
          _c("span", [_vm._v("Components")]),
        ]
      ),
      _vm._v(" "),
      _c(
        "div",
        {
          staticClass: "collapse",
          attrs: {
            id: "collapseTwo",
            "aria-labelledby": "headingTwo",
            "data-parent": "#accordionSidebar",
          },
        },
        [
          _c("div", { staticClass: "bg-white py-2 collapse-inner rounded" }, [
            _c("h6", { staticClass: "collapse-header" }, [
              _vm._v("Custom Components:"),
            ]),
            _vm._v(" "),
            _c(
              "a",
              { staticClass: "collapse-item", attrs: { href: "buttons.html" } },
              [_vm._v("Buttons")]
            ),
            _vm._v(" "),
            _c(
              "a",
              { staticClass: "collapse-item", attrs: { href: "cards.html" } },
              [_vm._v("Cards")]
            ),
          ]),
        ]
      ),
    ])
  },
  function () {
    var _vm = this
    var _h = _vm.$createElement
    var _c = _vm._self._c || _h
    return _c("li", { staticClass: "nav-item" }, [
      _c(
        "a",
        {
          staticClass: "nav-link collapsed",
          attrs: {
            href: "#",
            "data-toggle": "collapse",
            "data-target": "#collapseUtilities",
            "aria-expanded": "true",
            "aria-controls": "collapseUtilities",
          },
        },
        [
          _c("i", { staticClass: "fas fa-fw fa-wrench" }),
          _vm._v(" "),
          _c("span", [_vm._v("Utilities")]),
        ]
      ),
      _vm._v(" "),
      _c(
        "div",
        {
          staticClass: "collapse",
          attrs: {
            id: "collapseUtilities",
            "aria-labelledby": "headingUtilities",
            "data-parent": "#accordionSidebar",
          },
        },
        [
          _c("div", { staticClass: "bg-white py-2 collapse-inner rounded" }, [
            _c("h6", { staticClass: "collapse-header" }, [
              _vm._v("Custom Utilities:"),
            ]),
            _vm._v(" "),
            _c(
              "a",
              {
                staticClass: "collapse-item",
                attrs: { href: "utilities-color.html" },
              },
              [_vm._v("Colors")]
            ),
            _vm._v(" "),
            _c(
              "a",
              {
                staticClass: "collapse-item",
                attrs: { href: "utilities-border.html" },
              },
              [_vm._v("Borders")]
            ),
            _vm._v(" "),
            _c(
              "a",
              {
                staticClass: "collapse-item",
                attrs: { href: "utilities-animation.html" },
              },
              [_vm._v("Animations")]
            ),
            _vm._v(" "),
            _c(
              "a",
              {
                staticClass: "collapse-item",
                attrs: { href: "utilities-other.html" },
              },
              [_vm._v("Other")]
            ),
          ]),
        ]
      ),
    ])
  },
  function () {
    var _vm = this
    var _h = _vm.$createElement
    var _c = _vm._self._c || _h
    return _c(
      "a",
      {
        staticClass: "nav-link collapsed",
        attrs: {
          href: "#",
          "data-toggle": "collapse",
          "data-target": "#collapsePages",
          "aria-expanded": "true",
          "aria-controls": "collapsePages",
        },
      },
      [
        _c("i", { staticClass: "fas fa-fw fa-folder" }),
        _vm._v(" "),
        _c("span", [_vm._v("Management")]),
      ]
    )
  },
  function () {
    var _vm = this
    var _h = _vm.$createElement
    var _c = _vm._self._c || _h
    return _c("li", { staticClass: "nav-item" }, [
      _c("a", { staticClass: "nav-link", attrs: { href: "charts.html" } }, [
        _c("i", { staticClass: "fas fa-fw fa-chart-area" }),
        _vm._v(" "),
        _c("span", [_vm._v("Charts")]),
      ]),
    ])
  },
  function () {
    var _vm = this
    var _h = _vm.$createElement
    var _c = _vm._self._c || _h
    return _c("li", { staticClass: "nav-item" }, [
      _c("a", { staticClass: "nav-link", attrs: { href: "tables.html" } }, [
        _c("i", { staticClass: "fas fa-fw fa-table" }),
        _vm._v(" "),
        _c("span", [_vm._v("Tables")]),
      ]),
    ])
  },
  function () {
    var _vm = this
    var _h = _vm.$createElement
    var _c = _vm._self._c || _h
    return _c(
      "button",
      {
        staticClass: "btn btn-link d-md-none rounded-circle mr-3",
        attrs: { id: "sidebarToggleTop" },
      },
      [_c("i", { staticClass: "fa fa-bars" })]
    )
  },
  function () {
    var _vm = this
    var _h = _vm.$createElement
    var _c = _vm._self._c || _h
    return _c("ul", { staticClass: "navbar-nav ml-auto" }, [
      _c("li", { staticClass: "nav-item dropdown no-arrow d-sm-none" }, [
        _c(
          "a",
          {
            staticClass: "nav-link dropdown-toggle",
            attrs: {
              href: "#",
              id: "searchDropdown",
              role: "button",
              "data-toggle": "dropdown",
              "aria-haspopup": "true",
              "aria-expanded": "false",
            },
          },
          [_c("i", { staticClass: "fas fa-search fa-fw" })]
        ),
        _vm._v(" "),
        _c(
          "div",
          {
            staticClass:
              "dropdown-menu dropdown-menu-right p-3 shadow animated--grow-in",
            attrs: { "aria-labelledby": "searchDropdown" },
          },
          [
            _c(
              "form",
              { staticClass: "form-inline mr-auto w-100 navbar-search" },
              [
                _c("div", { staticClass: "input-group" }, [
                  _c("input", {
                    staticClass: "form-control bg-light border-0 small",
                    attrs: {
                      type: "text",
                      placeholder: "Search for...",
                      "aria-label": "Search",
                      "aria-describedby": "basic-addon2",
                    },
                  }),
                  _vm._v(" "),
                  _c("div", { staticClass: "input-group-append" }, [
                    _c(
                      "button",
                      {
                        staticClass: "btn btn-primary",
                        attrs: { type: "button" },
                      },
                      [_c("i", { staticClass: "fas fa-search fa-sm" })]
                    ),
                  ]),
                ]),
              ]
            ),
          ]
        ),
      ]),
      _vm._v(" "),
      _c("li", { staticClass: "nav-item dropdown no-arrow mx-1" }, [
        _c(
          "a",
          {
            staticClass: "nav-link dropdown-toggle",
            attrs: {
              href: "#",
              id: "alertsDropdown",
              role: "button",
              "data-toggle": "dropdown",
              "aria-haspopup": "true",
              "aria-expanded": "false",
            },
          },
          [
            _c("i", { staticClass: "fas fa-bell fa-fw" }),
            _vm._v(" "),
            _c("span", { staticClass: "badge badge-danger badge-counter" }, [
              _vm._v("3+"),
            ]),
          ]
        ),
        _vm._v(" "),
        _c(
          "div",
          {
            staticClass:
              "dropdown-list dropdown-menu dropdown-menu-right shadow animated--grow-in",
            attrs: { "aria-labelledby": "alertsDropdown" },
          },
          [
            _c("h6", { staticClass: "dropdown-header" }, [
              _vm._v(
                "\n                                Alerts Center\n                            "
              ),
            ]),
            _vm._v(" "),
            _c(
              "a",
              {
                staticClass: "dropdown-item d-flex align-items-center",
                attrs: { href: "#" },
              },
              [
                _c("div", { staticClass: "mr-3" }, [
                  _c("div", { staticClass: "icon-circle bg-primary" }, [
                    _c("i", { staticClass: "fas fa-file-alt text-white" }),
                  ]),
                ]),
                _vm._v(" "),
                _c("div", [
                  _c("div", { staticClass: "small text-gray-500" }, [
                    _vm._v("December 12, 2019"),
                  ]),
                  _vm._v(" "),
                  _c("span", { staticClass: "font-weight-bold" }, [
                    _vm._v("A new monthly report is ready to download!"),
                  ]),
                ]),
              ]
            ),
            _vm._v(" "),
            _c(
              "a",
              {
                staticClass: "dropdown-item d-flex align-items-center",
                attrs: { href: "#" },
              },
              [
                _c("div", { staticClass: "mr-3" }, [
                  _c("div", { staticClass: "icon-circle bg-success" }, [
                    _c("i", { staticClass: "fas fa-donate text-white" }),
                  ]),
                ]),
                _vm._v(" "),
                _c("div", [
                  _c("div", { staticClass: "small text-gray-500" }, [
                    _vm._v("December 7, 2019"),
                  ]),
                  _vm._v(
                    "\n                                    $290.29 has been deposited into your account!\n                                "
                  ),
                ]),
              ]
            ),
            _vm._v(" "),
            _c(
              "a",
              {
                staticClass: "dropdown-item d-flex align-items-center",
                attrs: { href: "#" },
              },
              [
                _c("div", { staticClass: "mr-3" }, [
                  _c("div", { staticClass: "icon-circle bg-warning" }, [
                    _c("i", {
                      staticClass: "fas fa-exclamation-triangle text-white",
                    }),
                  ]),
                ]),
                _vm._v(" "),
                _c("div", [
                  _c("div", { staticClass: "small text-gray-500" }, [
                    _vm._v("December 2, 2019"),
                  ]),
                  _vm._v(
                    "\n                                    Spending Alert: We've noticed unusually high spending for your account.\n                                "
                  ),
                ]),
              ]
            ),
            _vm._v(" "),
            _c(
              "a",
              {
                staticClass: "dropdown-item text-center small text-gray-500",
                attrs: { href: "#" },
              },
              [_vm._v("Show All Alerts")]
            ),
          ]
        ),
      ]),
      _vm._v(" "),
      _c("li", { staticClass: "nav-item dropdown no-arrow mx-1" }, [
        _c(
          "a",
          {
            staticClass: "nav-link dropdown-toggle",
            attrs: {
              href: "#",
              id: "messagesDropdown",
              role: "button",
              "data-toggle": "dropdown",
              "aria-haspopup": "true",
              "aria-expanded": "false",
            },
          },
          [
            _c("i", { staticClass: "fas fa-envelope fa-fw" }),
            _vm._v(" "),
            _c("span", { staticClass: "badge badge-danger badge-counter" }, [
              _vm._v("7"),
            ]),
          ]
        ),
        _vm._v(" "),
        _c(
          "div",
          {
            staticClass:
              "dropdown-list dropdown-menu dropdown-menu-right shadow animated--grow-in",
            attrs: { "aria-labelledby": "messagesDropdown" },
          },
          [
            _c("h6", { staticClass: "dropdown-header" }, [
              _vm._v(
                "\n                                Message Center\n                            "
              ),
            ]),
            _vm._v(" "),
            _c(
              "a",
              {
                staticClass: "dropdown-item d-flex align-items-center",
                attrs: { href: "#" },
              },
              [
                _c("div", { staticClass: "dropdown-list-image mr-3" }, [
                  _c("img", {
                    staticClass: "rounded-circle",
                    attrs: { src: "img/undraw_profile_1.svg", alt: "..." },
                  }),
                  _vm._v(" "),
                  _c("div", { staticClass: "status-indicator bg-success" }),
                ]),
                _vm._v(" "),
                _c("div", { staticClass: "font-weight-bold" }, [
                  _c("div", { staticClass: "text-truncate" }, [
                    _vm._v(
                      "Hi there! I am wondering if you can help me with a\n                                        problem I've been having."
                    ),
                  ]),
                  _vm._v(" "),
                  _c("div", { staticClass: "small text-gray-500" }, [
                    _vm._v("Emily Fowler · 58m"),
                  ]),
                ]),
              ]
            ),
            _vm._v(" "),
            _c(
              "a",
              {
                staticClass: "dropdown-item d-flex align-items-center",
                attrs: { href: "#" },
              },
              [
                _c("div", { staticClass: "dropdown-list-image mr-3" }, [
                  _c("img", {
                    staticClass: "rounded-circle",
                    attrs: { src: "img/undraw_profile_2.svg", alt: "..." },
                  }),
                  _vm._v(" "),
                  _c("div", { staticClass: "status-indicator" }),
                ]),
                _vm._v(" "),
                _c("div", [
                  _c("div", { staticClass: "text-truncate" }, [
                    _vm._v(
                      "I have the photos that you ordered last month, how\n                                        would you like them sent to you?"
                    ),
                  ]),
                  _vm._v(" "),
                  _c("div", { staticClass: "small text-gray-500" }, [
                    _vm._v("Jae Chun · 1d"),
                  ]),
                ]),
              ]
            ),
            _vm._v(" "),
            _c(
              "a",
              {
                staticClass: "dropdown-item d-flex align-items-center",
                attrs: { href: "#" },
              },
              [
                _c("div", { staticClass: "dropdown-list-image mr-3" }, [
                  _c("img", {
                    staticClass: "rounded-circle",
                    attrs: { src: "img/undraw_profile_3.svg", alt: "..." },
                  }),
                  _vm._v(" "),
                  _c("div", { staticClass: "status-indicator bg-warning" }),
                ]),
                _vm._v(" "),
                _c("div", [
                  _c("div", { staticClass: "text-truncate" }, [
                    _vm._v(
                      "Last month's report looks great, I am very happy with\n                                        the progress so far, keep up the good work!"
                    ),
                  ]),
                  _vm._v(" "),
                  _c("div", { staticClass: "small text-gray-500" }, [
                    _vm._v("Morgan Alvarez · 2d"),
                  ]),
                ]),
              ]
            ),
            _vm._v(" "),
            _c(
              "a",
              {
                staticClass: "dropdown-item d-flex align-items-center",
                attrs: { href: "#" },
              },
              [
                _c("div", { staticClass: "dropdown-list-image mr-3" }, [
                  _c("img", {
                    staticClass: "rounded-circle",
                    attrs: {
                      src: "https://source.unsplash.com/Mv9hjnEUHR4/60x60",
                      alt: "...",
                    },
                  }),
                  _vm._v(" "),
                  _c("div", { staticClass: "status-indicator bg-success" }),
                ]),
                _vm._v(" "),
                _c("div", [
                  _c("div", { staticClass: "text-truncate" }, [
                    _vm._v(
                      "Am I a good boy? The reason I ask is because someone\n                                        told me that people say this to all dogs, even if they aren't good..."
                    ),
                  ]),
                  _vm._v(" "),
                  _c("div", { staticClass: "small text-gray-500" }, [
                    _vm._v("Chicken the Dog · 2w"),
                  ]),
                ]),
              ]
            ),
            _vm._v(" "),
            _c(
              "a",
              {
                staticClass: "dropdown-item text-center small text-gray-500",
                attrs: { href: "#" },
              },
              [_vm._v("Read More Messages")]
            ),
          ]
        ),
      ]),
      _vm._v(" "),
      _c("div", { staticClass: "topbar-divider d-none d-sm-block" }),
      _vm._v(" "),
      _c("li", { staticClass: "nav-item dropdown no-arrow" }, [
        _c(
          "a",
          {
            staticClass: "nav-link dropdown-toggle",
            attrs: {
              href: "#",
              id: "userDropdown",
              role: "button",
              "data-toggle": "dropdown",
              "aria-haspopup": "true",
              "aria-expanded": "false",
            },
          },
          [
            _c(
              "span",
              { staticClass: "mr-2 d-none d-lg-inline text-gray-600 small" },
              [_vm._v("Douglas McGee")]
            ),
            _vm._v(" "),
            _c("img", {
              staticClass: "img-profile rounded-circle",
              attrs: { src: "img/undraw_profile.svg" },
            }),
          ]
        ),
        _vm._v(" "),
        _c(
          "div",
          {
            staticClass:
              "dropdown-menu dropdown-menu-right shadow animated--grow-in",
            attrs: { "aria-labelledby": "userDropdown" },
          },
          [
            _c("a", { staticClass: "dropdown-item", attrs: { href: "#" } }, [
              _c("i", {
                staticClass: "fas fa-user fa-sm fa-fw mr-2 text-gray-400",
              }),
              _vm._v(
                "\n                                Profile\n                            "
              ),
            ]),
            _vm._v(" "),
            _c("a", { staticClass: "dropdown-item", attrs: { href: "#" } }, [
              _c("i", {
                staticClass: "fas fa-cogs fa-sm fa-fw mr-2 text-gray-400",
              }),
              _vm._v(
                "\n                                Settings\n                            "
              ),
            ]),
            _vm._v(" "),
            _c("a", { staticClass: "dropdown-item", attrs: { href: "#" } }, [
              _c("i", {
                staticClass: "fas fa-list fa-sm fa-fw mr-2 text-gray-400",
              }),
              _vm._v(
                "\n                                Activity Log\n                            "
              ),
            ]),
            _vm._v(" "),
            _c("div", { staticClass: "dropdown-divider" }),
            _vm._v(" "),
            _c(
              "a",
              {
                staticClass: "dropdown-item",
                attrs: {
                  href: "#",
                  "data-toggle": "modal",
                  "data-target": "#logoutModal",
                },
              },
              [
                _c("i", {
                  staticClass:
                    "fas fa-sign-out-alt fa-sm fa-fw mr-2 text-gray-400",
                }),
                _vm._v(
                  "\n                                Logout\n                            "
                ),
              ]
            ),
          ]
        ),
      ]),
    ])
  },
  function () {
    var _vm = this
    var _h = _vm.$createElement
    var _c = _vm._self._c || _h
    return _c("div", { staticClass: "container-fluid" }, [
      _c(
        "div",
        {
          staticClass:
            "d-sm-flex align-items-center justify-content-between mb-4",
        },
        [
          _c("h1", { staticClass: "h3 mb-0 text-gray-800" }, [
            _vm._v("Dashboard"),
          ]),
          _vm._v(" "),
          _c(
            "a",
            {
              staticClass:
                "d-none d-sm-inline-block btn btn-sm btn-primary shadow-sm",
              attrs: { href: "#" },
            },
            [
              _c("i", { staticClass: "fas fa-download fa-sm text-white-50" }),
              _vm._v(" Generate Report"),
            ]
          ),
        ]
      ),
      _vm._v(" "),
      _c("div", { staticClass: "row" }, [
        _c("div", { staticClass: "col-xl-3 col-md-6 mb-4" }, [
          _c(
            "div",
            { staticClass: "card border-left-primary shadow h-100 py-2" },
            [
              _c("div", { staticClass: "card-body" }, [
                _c(
                  "div",
                  { staticClass: "row no-gutters align-items-center" },
                  [
                    _c("div", { staticClass: "col mr-2" }, [
                      _c(
                        "div",
                        {
                          staticClass:
                            "text-xs font-weight-bold text-primary text-uppercase mb-1",
                        },
                        [
                          _vm._v(
                            "\n                                            Earnings (Monthly)"
                          ),
                        ]
                      ),
                      _vm._v(" "),
                      _c(
                        "div",
                        {
                          staticClass: "h5 mb-0 font-weight-bold text-gray-800",
                        },
                        [_vm._v("$40,000")]
                      ),
                    ]),
                    _vm._v(" "),
                    _c("div", { staticClass: "col-auto" }, [
                      _c("i", {
                        staticClass: "fas fa-calendar fa-2x text-gray-300",
                      }),
                    ]),
                  ]
                ),
              ]),
            ]
          ),
        ]),
        _vm._v(" "),
        _c("div", { staticClass: "col-xl-3 col-md-6 mb-4" }, [
          _c(
            "div",
            { staticClass: "card border-left-success shadow h-100 py-2" },
            [
              _c("div", { staticClass: "card-body" }, [
                _c(
                  "div",
                  { staticClass: "row no-gutters align-items-center" },
                  [
                    _c("div", { staticClass: "col mr-2" }, [
                      _c(
                        "div",
                        {
                          staticClass:
                            "text-xs font-weight-bold text-success text-uppercase mb-1",
                        },
                        [
                          _vm._v(
                            "\n                                            Earnings (Annual)"
                          ),
                        ]
                      ),
                      _vm._v(" "),
                      _c(
                        "div",
                        {
                          staticClass: "h5 mb-0 font-weight-bold text-gray-800",
                        },
                        [_vm._v("$215,000")]
                      ),
                    ]),
                    _vm._v(" "),
                    _c("div", { staticClass: "col-auto" }, [
                      _c("i", {
                        staticClass: "fas fa-dollar-sign fa-2x text-gray-300",
                      }),
                    ]),
                  ]
                ),
              ]),
            ]
          ),
        ]),
        _vm._v(" "),
        _c("div", { staticClass: "col-xl-3 col-md-6 mb-4" }, [
          _c(
            "div",
            { staticClass: "card border-left-info shadow h-100 py-2" },
            [
              _c("div", { staticClass: "card-body" }, [
                _c(
                  "div",
                  { staticClass: "row no-gutters align-items-center" },
                  [
                    _c("div", { staticClass: "col mr-2" }, [
                      _c(
                        "div",
                        {
                          staticClass:
                            "text-xs font-weight-bold text-info text-uppercase mb-1",
                        },
                        [
                          _vm._v(
                            "Tasks\n                                        "
                          ),
                        ]
                      ),
                      _vm._v(" "),
                      _c(
                        "div",
                        { staticClass: "row no-gutters align-items-center" },
                        [
                          _c("div", { staticClass: "col-auto" }, [
                            _c(
                              "div",
                              {
                                staticClass:
                                  "h5 mb-0 mr-3 font-weight-bold text-gray-800",
                              },
                              [_vm._v("50%")]
                            ),
                          ]),
                          _vm._v(" "),
                          _c("div", { staticClass: "col" }, [
                            _c(
                              "div",
                              { staticClass: "progress progress-sm mr-2" },
                              [
                                _c("div", {
                                  staticClass: "progress-bar bg-info",
                                  staticStyle: { width: "50%" },
                                  attrs: {
                                    role: "progressbar",
                                    "aria-valuenow": "50",
                                    "aria-valuemin": "0",
                                    "aria-valuemax": "100",
                                  },
                                }),
                              ]
                            ),
                          ]),
                        ]
                      ),
                    ]),
                    _vm._v(" "),
                    _c("div", { staticClass: "col-auto" }, [
                      _c("i", {
                        staticClass:
                          "fas fa-clipboard-list fa-2x text-gray-300",
                      }),
                    ]),
                  ]
                ),
              ]),
            ]
          ),
        ]),
        _vm._v(" "),
        _c("div", { staticClass: "col-xl-3 col-md-6 mb-4" }, [
          _c(
            "div",
            { staticClass: "card border-left-warning shadow h-100 py-2" },
            [
              _c("div", { staticClass: "card-body" }, [
                _c(
                  "div",
                  { staticClass: "row no-gutters align-items-center" },
                  [
                    _c("div", { staticClass: "col mr-2" }, [
                      _c(
                        "div",
                        {
                          staticClass:
                            "text-xs font-weight-bold text-warning text-uppercase mb-1",
                        },
                        [
                          _vm._v(
                            "\n                                            Pending Requests"
                          ),
                        ]
                      ),
                      _vm._v(" "),
                      _c(
                        "div",
                        {
                          staticClass: "h5 mb-0 font-weight-bold text-gray-800",
                        },
                        [_vm._v("18")]
                      ),
                    ]),
                    _vm._v(" "),
                    _c("div", { staticClass: "col-auto" }, [
                      _c("i", {
                        staticClass: "fas fa-comments fa-2x text-gray-300",
                      }),
                    ]),
                  ]
                ),
              ]),
            ]
          ),
        ]),
      ]),
      _vm._v(" "),
      _c("div", { staticClass: "row" }, [
        _c("div", { staticClass: "col-xl-8 col-lg-7" }, [
          _c("div", { staticClass: "card shadow mb-4" }, [
            _c(
              "div",
              {
                staticClass:
                  "card-header py-3 d-flex flex-row align-items-center justify-content-between",
              },
              [
                _c("h6", { staticClass: "m-0 font-weight-bold text-primary" }, [
                  _vm._v("Earnings Overview"),
                ]),
                _vm._v(" "),
                _c("div", { staticClass: "dropdown no-arrow" }, [
                  _c(
                    "a",
                    {
                      staticClass: "dropdown-toggle",
                      attrs: {
                        href: "#",
                        role: "button",
                        id: "dropdownMenuLink",
                        "data-toggle": "dropdown",
                        "aria-haspopup": "true",
                        "aria-expanded": "false",
                      },
                    },
                    [
                      _c("i", {
                        staticClass:
                          "fas fa-ellipsis-v fa-sm fa-fw text-gray-400",
                      }),
                    ]
                  ),
                  _vm._v(" "),
                  _c(
                    "div",
                    {
                      staticClass:
                        "dropdown-menu dropdown-menu-right shadow animated--fade-in",
                      attrs: { "aria-labelledby": "dropdownMenuLink" },
                    },
                    [
                      _c("div", { staticClass: "dropdown-header" }, [
                        _vm._v("Dropdown Header:"),
                      ]),
                      _vm._v(" "),
                      _c(
                        "a",
                        { staticClass: "dropdown-item", attrs: { href: "#" } },
                        [_vm._v("Action")]
                      ),
                      _vm._v(" "),
                      _c(
                        "a",
                        { staticClass: "dropdown-item", attrs: { href: "#" } },
                        [_vm._v("Another action")]
                      ),
                      _vm._v(" "),
                      _c("div", { staticClass: "dropdown-divider" }),
                      _vm._v(" "),
                      _c(
                        "a",
                        { staticClass: "dropdown-item", attrs: { href: "#" } },
                        [_vm._v("Something else here")]
                      ),
                    ]
                  ),
                ]),
              ]
            ),
            _vm._v(" "),
            _c("div", { staticClass: "card-body" }, [
              _c("div", { staticClass: "chart-area" }, [
                _c("canvas", { attrs: { id: "myAreaChart" } }),
              ]),
            ]),
          ]),
        ]),
        _vm._v(" "),
        _c("div", { staticClass: "col-xl-4 col-lg-5" }, [
          _c("div", { staticClass: "card shadow mb-4" }, [
            _c(
              "div",
              {
                staticClass:
                  "card-header py-3 d-flex flex-row align-items-center justify-content-between",
              },
              [
                _c("h6", { staticClass: "m-0 font-weight-bold text-primary" }, [
                  _vm._v("Revenue Sources"),
                ]),
                _vm._v(" "),
                _c("div", { staticClass: "dropdown no-arrow" }, [
                  _c(
                    "a",
                    {
                      staticClass: "dropdown-toggle",
                      attrs: {
                        href: "#",
                        role: "button",
                        id: "dropdownMenuLink",
                        "data-toggle": "dropdown",
                        "aria-haspopup": "true",
                        "aria-expanded": "false",
                      },
                    },
                    [
                      _c("i", {
                        staticClass:
                          "fas fa-ellipsis-v fa-sm fa-fw text-gray-400",
                      }),
                    ]
                  ),
                  _vm._v(" "),
                  _c(
                    "div",
                    {
                      staticClass:
                        "dropdown-menu dropdown-menu-right shadow animated--fade-in",
                      attrs: { "aria-labelledby": "dropdownMenuLink" },
                    },
                    [
                      _c("div", { staticClass: "dropdown-header" }, [
                        _vm._v("Dropdown Header:"),
                      ]),
                      _vm._v(" "),
                      _c(
                        "a",
                        { staticClass: "dropdown-item", attrs: { href: "#" } },
                        [_vm._v("Action")]
                      ),
                      _vm._v(" "),
                      _c(
                        "a",
                        { staticClass: "dropdown-item", attrs: { href: "#" } },
                        [_vm._v("Another action")]
                      ),
                      _vm._v(" "),
                      _c("div", { staticClass: "dropdown-divider" }),
                      _vm._v(" "),
                      _c(
                        "a",
                        { staticClass: "dropdown-item", attrs: { href: "#" } },
                        [_vm._v("Something else here")]
                      ),
                    ]
                  ),
                ]),
              ]
            ),
            _vm._v(" "),
            _c("div", { staticClass: "card-body" }, [
              _c("div", { staticClass: "chart-pie pt-4 pb-2" }, [
                _c("canvas", { attrs: { id: "myPieChart" } }),
              ]),
              _vm._v(" "),
              _c("div", { staticClass: "mt-4 text-center small" }, [
                _c("span", { staticClass: "mr-2" }, [
                  _c("i", { staticClass: "fas fa-circle text-primary" }),
                  _vm._v(" Direct\n                                    "),
                ]),
                _vm._v(" "),
                _c("span", { staticClass: "mr-2" }, [
                  _c("i", { staticClass: "fas fa-circle text-success" }),
                  _vm._v(" Social\n                                    "),
                ]),
                _vm._v(" "),
                _c("span", { staticClass: "mr-2" }, [
                  _c("i", { staticClass: "fas fa-circle text-info" }),
                  _vm._v(" Referral\n                                    "),
                ]),
              ]),
            ]),
          ]),
        ]),
      ]),
      _vm._v(" "),
      _c("div", { staticClass: "row" }, [
        _c("div", { staticClass: "col-lg-6 mb-4" }, [
          _c("div", { staticClass: "card shadow mb-4" }, [
            _c("div", { staticClass: "card-header py-3" }, [
              _c("h6", { staticClass: "m-0 font-weight-bold text-primary" }, [
                _vm._v("Projects"),
              ]),
            ]),
            _vm._v(" "),
            _c("div", { staticClass: "card-body" }, [
              _c("h4", { staticClass: "small font-weight-bold" }, [
                _vm._v("Server Migration "),
                _c("span", { staticClass: "float-right" }, [_vm._v("20%")]),
              ]),
              _vm._v(" "),
              _c("div", { staticClass: "progress mb-4" }, [
                _c("div", {
                  staticClass: "progress-bar bg-danger",
                  staticStyle: { width: "20%" },
                  attrs: {
                    role: "progressbar",
                    "aria-valuenow": "20",
                    "aria-valuemin": "0",
                    "aria-valuemax": "100",
                  },
                }),
              ]),
              _vm._v(" "),
              _c("h4", { staticClass: "small font-weight-bold" }, [
                _vm._v("Sales Tracking "),
                _c("span", { staticClass: "float-right" }, [_vm._v("40%")]),
              ]),
              _vm._v(" "),
              _c("div", { staticClass: "progress mb-4" }, [
                _c("div", {
                  staticClass: "progress-bar bg-warning",
                  staticStyle: { width: "40%" },
                  attrs: {
                    role: "progressbar",
                    "aria-valuenow": "40",
                    "aria-valuemin": "0",
                    "aria-valuemax": "100",
                  },
                }),
              ]),
              _vm._v(" "),
              _c("h4", { staticClass: "small font-weight-bold" }, [
                _vm._v("Customer Database "),
                _c("span", { staticClass: "float-right" }, [_vm._v("60%")]),
              ]),
              _vm._v(" "),
              _c("div", { staticClass: "progress mb-4" }, [
                _c("div", {
                  staticClass: "progress-bar",
                  staticStyle: { width: "60%" },
                  attrs: {
                    role: "progressbar",
                    "aria-valuenow": "60",
                    "aria-valuemin": "0",
                    "aria-valuemax": "100",
                  },
                }),
              ]),
              _vm._v(" "),
              _c("h4", { staticClass: "small font-weight-bold" }, [
                _vm._v("Payout Details "),
                _c("span", { staticClass: "float-right" }, [_vm._v("80%")]),
              ]),
              _vm._v(" "),
              _c("div", { staticClass: "progress mb-4" }, [
                _c("div", {
                  staticClass: "progress-bar bg-info",
                  staticStyle: { width: "80%" },
                  attrs: {
                    role: "progressbar",
                    "aria-valuenow": "80",
                    "aria-valuemin": "0",
                    "aria-valuemax": "100",
                  },
                }),
              ]),
              _vm._v(" "),
              _c("h4", { staticClass: "small font-weight-bold" }, [
                _vm._v("Account Setup "),
                _c("span", { staticClass: "float-right" }, [
                  _vm._v("Complete!"),
                ]),
              ]),
              _vm._v(" "),
              _c("div", { staticClass: "progress" }, [
                _c("div", {
                  staticClass: "progress-bar bg-success",
                  staticStyle: { width: "100%" },
                  attrs: {
                    role: "progressbar",
                    "aria-valuenow": "100",
                    "aria-valuemin": "0",
                    "aria-valuemax": "100",
                  },
                }),
              ]),
            ]),
          ]),
          _vm._v(" "),
          _c("div", { staticClass: "row" }, [
            _c("div", { staticClass: "col-lg-6 mb-4" }, [
              _c("div", { staticClass: "card bg-primary text-white shadow" }, [
                _c("div", { staticClass: "card-body" }, [
                  _vm._v(
                    "\n                                        Primary\n                                        "
                  ),
                  _c("div", { staticClass: "text-white-50 small" }, [
                    _vm._v("#4e73df"),
                  ]),
                ]),
              ]),
            ]),
            _vm._v(" "),
            _c("div", { staticClass: "col-lg-6 mb-4" }, [
              _c("div", { staticClass: "card bg-success text-white shadow" }, [
                _c("div", { staticClass: "card-body" }, [
                  _vm._v(
                    "\n                                        Success\n                                        "
                  ),
                  _c("div", { staticClass: "text-white-50 small" }, [
                    _vm._v("#1cc88a"),
                  ]),
                ]),
              ]),
            ]),
            _vm._v(" "),
            _c("div", { staticClass: "col-lg-6 mb-4" }, [
              _c("div", { staticClass: "card bg-info text-white shadow" }, [
                _c("div", { staticClass: "card-body" }, [
                  _vm._v(
                    "\n                                        Info\n                                        "
                  ),
                  _c("div", { staticClass: "text-white-50 small" }, [
                    _vm._v("#36b9cc"),
                  ]),
                ]),
              ]),
            ]),
            _vm._v(" "),
            _c("div", { staticClass: "col-lg-6 mb-4" }, [
              _c("div", { staticClass: "card bg-warning text-white shadow" }, [
                _c("div", { staticClass: "card-body" }, [
                  _vm._v(
                    "\n                                        Warning\n                                        "
                  ),
                  _c("div", { staticClass: "text-white-50 small" }, [
                    _vm._v("#f6c23e"),
                  ]),
                ]),
              ]),
            ]),
            _vm._v(" "),
            _c("div", { staticClass: "col-lg-6 mb-4" }, [
              _c("div", { staticClass: "card bg-danger text-white shadow" }, [
                _c("div", { staticClass: "card-body" }, [
                  _vm._v(
                    "\n                                        Danger\n                                        "
                  ),
                  _c("div", { staticClass: "text-white-50 small" }, [
                    _vm._v("#e74a3b"),
                  ]),
                ]),
              ]),
            ]),
            _vm._v(" "),
            _c("div", { staticClass: "col-lg-6 mb-4" }, [
              _c(
                "div",
                { staticClass: "card bg-secondary text-white shadow" },
                [
                  _c("div", { staticClass: "card-body" }, [
                    _vm._v(
                      "\n                                        Secondary\n                                        "
                    ),
                    _c("div", { staticClass: "text-white-50 small" }, [
                      _vm._v("#858796"),
                    ]),
                  ]),
                ]
              ),
            ]),
            _vm._v(" "),
            _c("div", { staticClass: "col-lg-6 mb-4" }, [
              _c("div", { staticClass: "card bg-light text-black shadow" }, [
                _c("div", { staticClass: "card-body" }, [
                  _vm._v(
                    "\n                                        Light\n                                        "
                  ),
                  _c("div", { staticClass: "text-black-50 small" }, [
                    _vm._v("#f8f9fc"),
                  ]),
                ]),
              ]),
            ]),
            _vm._v(" "),
            _c("div", { staticClass: "col-lg-6 mb-4" }, [
              _c("div", { staticClass: "card bg-dark text-white shadow" }, [
                _c("div", { staticClass: "card-body" }, [
                  _vm._v(
                    "\n                                        Dark\n                                        "
                  ),
                  _c("div", { staticClass: "text-white-50 small" }, [
                    _vm._v("#5a5c69"),
                  ]),
                ]),
              ]),
            ]),
          ]),
        ]),
        _vm._v(" "),
        _c("div", { staticClass: "col-lg-6 mb-4" }, [
          _c("div", { staticClass: "card shadow mb-4" }, [
            _c("div", { staticClass: "card-header py-3" }, [
              _c("h6", { staticClass: "m-0 font-weight-bold text-primary" }, [
                _vm._v("Illustrations"),
              ]),
            ]),
            _vm._v(" "),
            _c("div", { staticClass: "card-body" }, [
              _c("div", { staticClass: "text-center" }, [
                _c("img", {
                  staticClass: "img-fluid px-3 px-sm-4 mt-3 mb-4",
                  staticStyle: { width: "25rem" },
                  attrs: { src: "img/undraw_posting_photo.svg", alt: "..." },
                }),
              ]),
              _vm._v(" "),
              _c("p", [
                _vm._v(
                  "Add some quality, svg illustrations to your project courtesy of "
                ),
                _c(
                  "a",
                  {
                    attrs: {
                      target: "_blank",
                      rel: "nofollow",
                      href: "https://undraw.co/",
                    },
                  },
                  [_vm._v("unDraw")]
                ),
                _vm._v(
                  ", a\n                                    constantly updated collection of beautiful svg images that you can use\n                                    completely free and without attribution!"
                ),
              ]),
              _vm._v(" "),
              _c(
                "a",
                {
                  attrs: {
                    target: "_blank",
                    rel: "nofollow",
                    href: "https://undraw.co/",
                  },
                },
                [
                  _vm._v(
                    "Browse Illustrations on\n                                    unDraw →"
                  ),
                ]
              ),
            ]),
          ]),
          _vm._v(" "),
          _c("div", { staticClass: "card shadow mb-4" }, [
            _c("div", { staticClass: "card-header py-3" }, [
              _c("h6", { staticClass: "m-0 font-weight-bold text-primary" }, [
                _vm._v("Development Approach"),
              ]),
            ]),
            _vm._v(" "),
            _c("div", { staticClass: "card-body" }, [
              _c("p", [
                _vm._v(
                  "SB Admin 2 makes extensive use of Bootstrap 4 utility classes in order to reduce\n                                    CSS bloat and poor page performance. Custom CSS classes are used to create\n                                    custom components and custom utility classes."
                ),
              ]),
              _vm._v(" "),
              _c("p", { staticClass: "mb-0" }, [
                _vm._v(
                  "Before working with this theme, you should become familiar with the\n                                    Bootstrap framework, especially the utility classes."
                ),
              ]),
            ]),
          ]),
        ]),
      ]),
    ])
  },
]
render._withStripped = true



/***/ })

}]);